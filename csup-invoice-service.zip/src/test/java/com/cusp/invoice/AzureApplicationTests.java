package com.cusp.invoice;

import org.junit.jupiter.api.Test;

class AzureApplicationTests {

	@Test
	void contextLoads() {
	}
}
