package com.csup.invoice.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class InvoiceStatus {

	public static final String NEW = "NEW";
	public static final String DRAFT = "DRAFT";
	public static final String GENERATED = "GENERATED";
}
