package com.csup.invoice.exception;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;

import org.springframework.http.ResponseEntity;

import com.csup.invoice.restresponse.ErrorRestResponse;

import lombok.Getter;

@Getter
public class AppException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
    private ErrorRestResponse restResponse;

    public AppException(ErrorRestResponse restResponse) {
        assertThat(restResponse).isNotNull();
        this.message = restResponse.getError().getMessage();
        this.restResponse = restResponse;
        this.restResponse.setStackTrace(Arrays.stream(this.getStackTrace()).map(trace -> trace.toString()).toArray());
    }

    public ResponseEntity<?> responseEntity() {
        return this.restResponse.responseEntity();
    }
}
