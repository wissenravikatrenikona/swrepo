package com.csup.invoice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.csup.invoice.dto.InvoiceDTO;
import com.csup.invoice.entity.Invoice;
import com.csup.invoice.entity.InvoiceHistroy;
import com.csup.invoice.entity.InvoiceTransactionAssociation;
import com.csup.invoice.entity.InvoiceTransactionKey;
import com.csup.invoice.exception.AppException;
import com.csup.invoice.repository.InvoiceHistoryRepository;
import com.csup.invoice.repository.InvoiceRepository;
import com.csup.invoice.repository.InvoiceTransactionAssociationRepo;
import com.csup.invoice.restresponse.ErrorRestResponse;
import com.csup.invoice.restresponse.OkRestResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	private InvoiceRepository invoiceRepository;
	
	@Autowired
	private InvoiceHistoryRepository invoiceHistoryRepository;

	@Autowired
	private InvoiceTransactionAssociationRepo invoiceTransactionAssociationRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public OkRestResponse findAll(Long tranId) {
		log.info("get invoice list..");
		return findByTranscationId(tranId);
	}

	@Override
	public OkRestResponse findInvoiceById(Long tranId, Long invoiceId) {
		Optional<Invoice> optInvoice = invoiceRepository.findById(invoiceId);
		if (optInvoice.isPresent()) {
			OkRestResponse restResponse = new OkRestResponse();
			restResponse.setCollection(false);
			restResponse.setStatus(HttpStatus.OK);
			restResponse.setData(modelMapper.map(optInvoice.get(), InvoiceDTO.class));
			return restResponse;
		}
		throw new AppException(ErrorRestResponse.notFound());
	}

	@Override
	public OkRestResponse createInvoice(Long tranId, InvoiceDTO invoiceDTO) {
		Invoice invoice = modelMapper.map(invoiceDTO, Invoice.class);
		invoice = invoiceRepository.save(invoice);
		invoiceTransactionAssociationRepo
				.save(new InvoiceTransactionAssociation(new InvoiceTransactionKey(tranId, invoice.getInvoiceId())));
		OkRestResponse restResponse = new OkRestResponse();
		restResponse.setCollection(false);
		restResponse.setStatus(HttpStatus.OK);
		restResponse.setData(modelMapper.map(invoice, InvoiceDTO.class));
		return restResponse;
	}

	@Override
	public OkRestResponse findByTranscationId(Long tranId) {
		List<InvoiceTransactionAssociation> invoices = invoiceTransactionAssociationRepo.findByPk_CsupId(tranId);
		List<Long> invoiceIdList = invoices.stream().map(a -> a.getPk().getInvoiceId()).collect(Collectors.toList());
		List<Invoice> invoiceList = invoiceRepository.findByInvoiceIdIn(invoiceIdList);
		OkRestResponse restResponse = new OkRestResponse();
		restResponse.setCollection(true);
		restResponse.setStatus(HttpStatus.OK);
		restResponse.setData(invoiceList.stream().map(i -> modelMapper.map(i, InvoiceDTO.class)).collect(Collectors.toList()));
		return restResponse;
	}

	@Override
	public OkRestResponse updateInvoice(Long tranId, Long invoiceId, InvoiceDTO invoiceDTO) {
		Invoice invoice = modelMapper.map(invoiceDTO, Invoice.class);
		invoice.setInvoiceId(invoiceId);
		invoiceHistoryRepository.save(modelMapper.map(invoice, InvoiceHistroy.class));
		invoice = invoiceRepository.save(invoice);
		OkRestResponse restResponse = new OkRestResponse();
		restResponse.setCollection(false);
		restResponse.setStatus(HttpStatus.OK);
		restResponse.setData(modelMapper.map(invoice, InvoiceDTO.class));
		return restResponse;
	}

	@Override
	public OkRestResponse deleteById(Long tranId, Long invoiceId) {
		invoiceTransactionAssociationRepo.deleteByTranIdAndInvoiceId(tranId, invoiceId);
		invoiceRepository.deleteById(invoiceId);
		OkRestResponse restResponse = new OkRestResponse();
		restResponse.setStatus(HttpStatus.OK);
		return restResponse;
	}

	@Override
	public OkRestResponse copyInvoice(Long tranId, Long invoiceId) {
		OkRestResponse restResponse = new OkRestResponse();
		Optional<Invoice> optInvoice = invoiceRepository.findById(invoiceId);
		if(optInvoice.isPresent()) {
			Invoice invoice = new Invoice(); 
			BeanUtils.copyProperties(optInvoice.get(), invoice);
			invoice.setInvoiceId(null);
			invoice = invoiceRepository.save(invoice);
			invoiceTransactionAssociationRepo.save(new InvoiceTransactionAssociation(new InvoiceTransactionKey(tranId, invoice.getInvoiceId())));
			restResponse.setStatus(HttpStatus.OK);
			restResponse.setData(modelMapper.map(invoice, InvoiceDTO.class));
		} else {
			restResponse.setStatus(HttpStatus.EXPECTATION_FAILED);
		}
		return restResponse;
	}

}
