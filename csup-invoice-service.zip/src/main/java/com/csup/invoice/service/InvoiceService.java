package com.csup.invoice.service;

import com.csup.invoice.dto.InvoiceDTO;
import com.csup.invoice.restresponse.OkRestResponse;

public interface InvoiceService {

	OkRestResponse findAll(Long tranId);

	OkRestResponse findInvoiceById(Long tranId, Long invoiceId);

	OkRestResponse createInvoice(Long tranId, InvoiceDTO invoiceDTO);
	
	OkRestResponse updateInvoice(Long tranId, Long invoiceId, InvoiceDTO invoiceDTO);

	OkRestResponse findByTranscationId(Long tranId);

	OkRestResponse deleteById(Long tranId, Long invoiceId);

	OkRestResponse copyInvoice(Long tranId, Long invoiceId);

}
