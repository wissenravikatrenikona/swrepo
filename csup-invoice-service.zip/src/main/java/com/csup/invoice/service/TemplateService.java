package com.csup.invoice.service;

import com.csup.invoice.entity.TemplateDetail;
import com.csup.invoice.restresponse.OkRestResponse;

public interface TemplateService {

	OkRestResponse findByCarrierId(Integer carrierId);

	OkRestResponse createTemplate(Integer carrierId, TemplateDetail templateDetail);

	OkRestResponse findByCarrierIdTemplateId(Integer carrierId, Integer templateId);

}
