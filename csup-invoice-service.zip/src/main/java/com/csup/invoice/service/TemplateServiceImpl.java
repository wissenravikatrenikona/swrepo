package com.csup.invoice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csup.invoice.entity.CarrierTemplateAssociation;
import com.csup.invoice.entity.CarrierTemplateKey;
import com.csup.invoice.entity.TemplateDetail;
import com.csup.invoice.repository.CarrierTemplateAssociationRepo;
import com.csup.invoice.repository.TemplateDetailRepo;
import com.csup.invoice.restresponse.OkRestResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TemplateServiceImpl implements TemplateService {

	@Autowired
	private TemplateDetailRepo templateDetailRepo;

	@Autowired
	private CarrierTemplateAssociationRepo carrierTemplateAssociationRepo;

	@Override
	public OkRestResponse findByCarrierId(Integer carrierId) {
		log.info("findByCarrierId {}", carrierId);
		List<CarrierTemplateAssociation> associations = carrierTemplateAssociationRepo.findByPk_CarrierId(carrierId);
		List<Integer> templateIds = associations.stream().map(as -> as.getPk().getTemplateId())
				.collect(Collectors.toList());
		List<TemplateDetail> templateDetails = templateDetailRepo.findAllById(templateIds);
		OkRestResponse okRestResponse = new OkRestResponse();
		okRestResponse.setCollection(true);
		okRestResponse.setData(templateDetails);
		return okRestResponse;
	}

	@Override
	public OkRestResponse createTemplate(Integer carrierId, TemplateDetail templateDetail) {
		log.info("saveTemplateDetail...");
		templateDetail.setTemplateId((int) templateDetailRepo.count() + 1);
		templateDetail = templateDetailRepo.save(templateDetail);
		carrierTemplateAssociationRepo.save(new CarrierTemplateAssociation(new CarrierTemplateKey(carrierId, templateDetail.getTemplateId())));
		OkRestResponse okRestResponse = new OkRestResponse();
		okRestResponse.setCollection(false);
		okRestResponse.setData(templateDetail);
		return okRestResponse;
	}

	@Override
	public OkRestResponse findByCarrierIdTemplateId(Integer carrierId, Integer templateId) {
		log.info("findByCarrierId {}", carrierId);
		Optional<TemplateDetail> templateDetails = templateDetailRepo.findById(templateId);
		OkRestResponse okRestResponse = new OkRestResponse();
		okRestResponse.setCollection(false);
		if (templateDetails.isPresent()) {
			okRestResponse.setData(templateDetails.get());
		}
		return okRestResponse;
	}

}
