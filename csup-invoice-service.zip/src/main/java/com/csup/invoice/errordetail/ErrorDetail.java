package com.csup.invoice.errordetail;

public interface ErrorDetail {
	String getCode();

	String getMessage();

	String toString();
}
