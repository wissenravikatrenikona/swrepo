package com.csup.invoice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class InvoiceTransactionKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8245347383674867701L;

	@Column(name = "CSUPID", nullable = false)
	private Long csupId;

	@Column(name = "INVOICE_ID", nullable = false)
	private Long invoiceId;
}
