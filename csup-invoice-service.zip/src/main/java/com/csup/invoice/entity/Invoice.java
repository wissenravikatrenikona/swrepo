package com.csup.invoice.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "INVOICE_INFO")
public class Invoice implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 170441167455540718L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "INVOICE_ID", unique = true, nullable = false, updatable = false)
	private Long invoiceId;

	@Column(name = "STATUS", length = 100)
	private String status;

	@Column(name = "TERM_OF_PAYMENT")
	private Integer paymentTerm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REQUEST_RECEIPT_DATE")
	private Date receiptDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INVOICE_DATE")
	private Date invoiceDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DUE_DATE")
	private Date dueDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INVOICE_PERIOD_FROM")
	private Date periodFom;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "INVOICE_PERIOD_TO")
	private Date periodTo;

	@Column(name = "CURRENCY", length = 100)
	private String currency;

	@Column(name = "AMOUNT", precision = 38, scale = 16)
	private Double amount;
	
	@Column(name = "INVOICE_DOCUMENT")
	private String invoiceDocument;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_TIME")
	private Date createdTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATED_TIME")
	private Date updatedTime;

	@Column(name = "CREATED_BY", length = 100)
	private String createdBy;

	@Column(name = "UPDATED_BY", length = 100)
	private String updatedBy;
	
	@PrePersist
	public void prePersist() {
		this.setCreatedTime(new Date());
	}
	
	@PreUpdate
	public void preUpdate() {
		this.setUpdatedTime(new Date());
	}
}
