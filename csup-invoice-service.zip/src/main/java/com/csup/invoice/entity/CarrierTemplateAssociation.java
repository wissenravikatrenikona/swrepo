package com.csup.invoice.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "LEGAL_CARRIER_TEMPLATE_ASSOCIATION")
public class CarrierTemplateAssociation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -125L;

	@EmbeddedId
	private CarrierTemplateKey pk;
	
}
