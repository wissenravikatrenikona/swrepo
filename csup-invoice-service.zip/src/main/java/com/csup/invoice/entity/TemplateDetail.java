package com.csup.invoice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "LEGAL_CARRIER_TEMPLATE_DETAILS")
public class TemplateDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 199130553034227643L;

	@Id
	@Column(name = "TEMPLATE_ID", unique = true, nullable = false, updatable = false)
	private Integer templateId;

	@Column(name = "TEMPLATE_WORD")
	private String templateWord;

	@Column(name = "TEMPLATE_BASE64")
	private String templateBase64;

}
