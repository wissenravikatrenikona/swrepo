package com.csup.invoice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class CarrierTemplateKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;

	@Column(name = "CARRIER_ID", nullable = false)
	private Integer carrierId;
	
	@Column(name = "TEMPLATE_ID", nullable = false)
	private Integer templateId;

}
