package com.csup.invoice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csup.invoice.entity.TemplateDetail;
import com.csup.invoice.restresponse.OkRestResponse;
import com.csup.invoice.service.TemplateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/{carrierId}/templates")
public class TemplateController {

	@Autowired
	private TemplateService templateService;

	@GetMapping
	public OkRestResponse findByCarrierId(@PathVariable("carrierId") Integer carrierId) {
		OkRestResponse okRestResponse = templateService.findByCarrierId(carrierId);
		log.info("findByCarrierId status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
	
	@GetMapping("/{templateId}")
	public OkRestResponse findByCarrierIdTemplateId(@PathVariable("carrierId") Integer carrierId, @PathVariable("templateId") Integer templateId) {
		OkRestResponse okRestResponse = templateService.findByCarrierIdTemplateId(carrierId, templateId);
		log.info("findByCarrierIdTemplateId status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
	
	@PostMapping
	public OkRestResponse createTemplate(@PathVariable("carrierId") Integer carrierId, @RequestBody TemplateDetail templateDetail) {
		OkRestResponse okRestResponse = templateService.createTemplate(carrierId, templateDetail);
		log.info("createTemplate status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
	
}
