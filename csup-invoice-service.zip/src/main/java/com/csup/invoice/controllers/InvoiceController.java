package com.csup.invoice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csup.invoice.dto.InvoiceDTO;
import com.csup.invoice.restresponse.OkRestResponse;
import com.csup.invoice.service.InvoiceService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/{tranId}/invoices")
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;

	@GetMapping
	public OkRestResponse findAllInvoice(@PathVariable("tranId") Long tranId) {
		OkRestResponse okRestResponse = invoiceService.findAll(tranId);
		log.info("findAllInvoice status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
	
	@PostMapping
	public OkRestResponse createInvoice(@PathVariable("tranId") Long tranId, @RequestBody InvoiceDTO invoiceDTO) {
		OkRestResponse okRestResponse = invoiceService.createInvoice(tranId, invoiceDTO);
		log.info("createInvoice status {} ", okRestResponse.getStatus());
		return okRestResponse;
	} 
	
	@PostMapping("/{invoiceId}/copy")
	public OkRestResponse copyInvoice(@PathVariable("tranId") Long tranId, @PathVariable("invoiceId") Long invoiceId) {
		OkRestResponse okRestResponse = invoiceService.copyInvoice(tranId, invoiceId);
		log.info("copyInvoice status {} ", okRestResponse.getStatus());
		return okRestResponse;
	} 
	
	@PutMapping("/{invoiceId}")
	public OkRestResponse updateInvoice(@PathVariable("tranId") Long tranId, 
		@PathVariable("invoiceId") Long invoiceId, @RequestBody InvoiceDTO invoiceDTO) {
		OkRestResponse okRestResponse = invoiceService.updateInvoice(tranId, invoiceId, invoiceDTO);
		log.info("createInvoice status {} ", okRestResponse.getStatus());
		return okRestResponse;
	} 
	
	@GetMapping("/{invoiceId}")
	public OkRestResponse findInvoiceById(@PathVariable("tranId") Long tranId, @PathVariable("invoiceId") Long invoiceId) {
		OkRestResponse okRestResponse = invoiceService.findInvoiceById(tranId, invoiceId);
		log.info("findInvoiceById status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
	
	@DeleteMapping("/{invoiceId}")
	public OkRestResponse deleteById(@PathVariable("tranId") Long tranId, @PathVariable("invoiceId") Long invoiceId) {
		OkRestResponse okRestResponse = invoiceService.deleteById(tranId, invoiceId);
		log.info("deleteById status {} ", okRestResponse.getStatus());
		return okRestResponse;
	}
}
