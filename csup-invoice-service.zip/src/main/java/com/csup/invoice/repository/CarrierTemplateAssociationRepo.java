package com.csup.invoice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.csup.invoice.entity.CarrierTemplateAssociation;
import com.csup.invoice.entity.CarrierTemplateKey;

@Repository
public interface CarrierTemplateAssociationRepo extends JpaRepository<CarrierTemplateAssociation, CarrierTemplateKey> {

	List<CarrierTemplateAssociation> findByPk_CarrierId(Integer carrierId);

}
