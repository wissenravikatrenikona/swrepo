package com.csup.invoice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.csup.invoice.entity.InvoiceHistroy;

@Repository
public interface InvoiceHistoryRepository extends JpaRepository<InvoiceHistroy, Long> {

}
