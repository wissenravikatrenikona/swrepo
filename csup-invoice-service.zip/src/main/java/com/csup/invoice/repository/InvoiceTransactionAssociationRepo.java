package com.csup.invoice.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.csup.invoice.entity.InvoiceTransactionAssociation;
import com.csup.invoice.entity.InvoiceTransactionKey;

@Repository
public interface InvoiceTransactionAssociationRepo
		extends JpaRepository<InvoiceTransactionAssociation, InvoiceTransactionKey> {

	List<InvoiceTransactionAssociation> findByPk_CsupId(Long tranId);

	@Modifying
	@Transactional
	@Query(value = "delete from INVOICE_TRANSACTION_ASSOCIATION where CSUPID = :tranId AND INVOICE_ID = :invoiceId", nativeQuery = true)
	void deleteByTranIdAndInvoiceId(@Param("tranId") Long tranId, @Param("invoiceId") Long invoiceId);

}
