package com.csup.invoice.restresponse;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Getter
@Setter
public abstract class RestResponse {
	private long timestamp = System.currentTimeMillis();
	private HttpStatus status;

	public abstract ResponseEntity<?> responseEntity();
}