package com.csup.invoice.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1721184940451582486L;

	private Long invoiceId;

	private String status;

	private Integer paymentTerm;

	private String receiptDate;

	private String invoiceDate;

	private String dueDate;

	private String periodFom;

	private String periodTo;

	private String currency;

	private Double amount;
	
	private String createdTime;

	private String updatedTime;

	private String createdBy;

	private String updatedBy;
	
	private String invoiceDocument;

}
