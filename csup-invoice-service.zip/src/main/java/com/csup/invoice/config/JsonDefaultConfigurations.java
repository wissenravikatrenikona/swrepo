package com.csup.invoice.config;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.AbstractConverter;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.annotation.JsonInclude;

@Configuration
public class JsonDefaultConfigurations {

	private DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	private DateFormat destDf = new SimpleDateFormat("dd/MM/yyyy");

	@Bean
	public Jackson2ObjectMapperBuilderCustomizer jsonCustomizer() {
		return builder -> builder.serializationInclusion(JsonInclude.Include.NON_NULL).failOnUnknownProperties(false);
	}

	@Bean
	public ModelMapper modelMapper() {
		ModelMapper mapper = new ModelMapper();
		mapper.addConverter(strToDateConvertor);
		mapper.addConverter(dateToStrConvertor);
		return mapper;
	}

	private Converter<String, Date> strToDateConvertor = new AbstractConverter<String, Date>() {
		protected Date convert(String source) {
			try {
				return StringUtils.isBlank(source) ? null : df.parse(source);
			} catch (ParseException e) {
				return null;
			}
		}
	};
	
	private Converter<Date, String> dateToStrConvertor = new AbstractConverter<Date, String>() {
		protected String convert(Date source) {
			return source == null? null : destDf.format(source);
		}
	};
}
